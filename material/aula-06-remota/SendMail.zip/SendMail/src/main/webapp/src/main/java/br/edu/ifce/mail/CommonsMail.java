package br.edu.ifce.mail;
import java.net.MalformedURLException;

import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.MultiPartEmail;
import org.apache.commons.mail.SimpleEmail;

import br.edu.ifce.bean.Mail;

public class CommonsMail {
	
	  public CommonsMail() throws EmailException, MalformedURLException {  
	     Mail m = new Mail();
	     m.setAssunto("Corneli");
	     m.setDestinatario("junior.corneli83@gmail.com");
	     m.setMensagem("bsdjfd");
		 enviaEmailSimples(m);   
	     System.out.println("Email enviado com sucesso.");
	    } 
	  
	  
	public void enviaEmailSimples(Mail mail) throws EmailException { 
		 
		  SimpleEmail email = new SimpleEmail();  
		  email.setHostName("smtp.googlemail.com");
		  email.setSmtpPort(587);
		  email.setAuthentication("app.sesi.ce@gmail.com", "app.sesi.ce2017"); 
		  email.setFrom("app.sesi.ce@gmail.com","Loja Online");
		  email.setSSL(true);  
	      email.setTLS(true); 
		  email.setSubject(mail.getAssunto());
		  email.setMsg(mail.getMensagem());
		  email.addTo(mail.getDestinatario());
		  email.send();
	  }
		
	public static void main(String[] args) throws EmailException, MalformedURLException {  
		new CommonsMail();  
	}		

}
